import pandas as pd

def veri_girisi():
    """Kullanıcıdan virgülle ayrılmış sayılar alır ve pandas Serisi olarak döndürür."""
    veri = input("Sayıları virgülle ayırarak girin: ")
    veri_listesi = list(map(float, veri.split(',')))
    return pd.Series(veri_listesi)

def istatistik_hesapla(veri):
    """Verilen veri Serisinin istatistiksel hesaplamalarını yapar ve sonuçları döndürür."""
    hesaplamalar = {}
    hesaplamalar['Ortalama'] = veri.mean()
    hesaplamalar['Medyan'] = veri.median()
    hesaplamalar['Ortanca (Median Low)'] = veri.sort_values().iloc[len(veri)//2 - (1 if len(veri) % 2 == 0 else 0)]
    hesaplamalar['Varyans'] = veri.var()
    hesaplamalar['Standart Sapma'] = veri.std()
    
    # Mod hesaplaması
    mod_deger = veri.mode()
    hesaplamalar['Mod'] = mod_deger.iloc[0] if not mod_deger.empty else "Tanımsız (Birden fazla mod var veya tüm değerler aynı)"
    
    return hesaplamalar

def sonuc_yazdir(hesaplamalar):
    """Hesaplamaları ekrana yazdırır."""
    print("\nİstatistiksel Değerler:")
    for anahtar, deger in hesaplamalar.items():
        print(f"{anahtar}: {deger}")

# Ana program akışı
veri = veri_girisi()
hesaplamalar = istatistik_hesapla(veri)
sonuc_yazdir(hesaplamalar)
